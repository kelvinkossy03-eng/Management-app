import React, { useEffect, useMemo, useState } from 'react'
import { createRoot } from 'react-dom/client'
import {
  Activity, ArrowDownRight, ArrowUpRight, Bell, BriefcaseBusiness, Building2,
  CalendarDays, Check, ChevronDown, CircleHelp, CreditCard, Download, FileBarChart,
  LayoutDashboard, Menu, MoreHorizontal, Package, Plus, Search, Settings, ShoppingBag,
  ShoppingCart, Sparkles, TrendingUp, Users, Wallet, X, ReceiptText, Truck, LogOut
} from 'lucide-react'
import { Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis } from 'recharts'
import './styles.css'

const defaultProducts = [
  { id: 1, name: 'Jollof Rice', sku: 'FD-001', category: 'Food', price: 3500, cost: 1900, stock: 28 },
  { id: 2, name: 'Grilled Chicken', sku: 'FD-002', category: 'Food', price: 4500, cost: 2700, stock: 14 },
  { id: 3, name: 'Soft Drink', sku: 'DR-003', category: 'Drinks', price: 700, cost: 350, stock: 9 },
  { id: 4, name: 'Bottled Water', sku: 'DR-004', category: 'Drinks', price: 400, cost: 180, stock: 42 },
  { id: 5, name: 'Fried Rice', sku: 'FD-005', category: 'Food', price: 4000, cost: 2200, stock: 6 },
]
const initialSales = [
  { id: 'S-1048', item: 'Jollof Rice × 2', customer: 'Walk-in customer', method: 'Cash', amount: 7000, date: 'Today, 10:42 AM', status: 'Completed' },
  { id: 'S-1047', item: 'Grilled Chicken × 1', customer: 'Ada Okafor', method: 'Transfer', amount: 4500, date: 'Today, 10:18 AM', status: 'Completed' },
  { id: 'S-1046', item: 'Fried Rice × 2', customer: 'Walk-in customer', method: 'POS', amount: 8000, date: 'Today, 9:54 AM', status: 'Completed' },
  { id: 'S-1045', item: 'Soft Drink × 3', customer: 'Emeka James', method: 'Cash', amount: 2100, date: 'Today, 9:31 AM', status: 'Completed' },
]
const initialExpenses = [
  { id: 'EX-101', name: 'Food supplies', category: 'Inventory', amount: 42000, date: 'Today' },
  { id: 'EX-100', name: 'Generator fuel', category: 'Utilities', amount: 8500, date: 'Yesterday' },
  { id: 'EX-099', name: 'Staff transport', category: 'Staff', amount: 6000, date: 'Yesterday' },
]
const chartData = [
  { day: 'Mon', sales: 92000 }, { day: 'Tue', sales: 115000 }, { day: 'Wed', sales: 87000 },
  { day: 'Thu', sales: 142000 }, { day: 'Fri', sales: 128000 }, { day: 'Sat', sales: 186000 }, { day: 'Sun', sales: 154000 },
]
const naira = n => new Intl.NumberFormat('en-NG', { style: 'currency', currency: 'NGN', maximumFractionDigits: 0 }).format(n || 0)
const load = (key, fallback) => { try { const v = localStorage.getItem(key); return v ? JSON.parse(v) : fallback } catch { return fallback } }

function App() {
  const [business, setBusiness] = useState(() => load('bos_business', { name: 'Village Kitchen & Bar', type: 'Restaurant / Bar', staff: '2–5 staff', branches: '1 location', goal: 'Know my real profit' }))
  const [products, setProducts] = useState(() => load('bos_products', defaultProducts))
  const [sales, setSales] = useState(() => load('bos_sales', initialSales))
  const [expenses, setExpenses] = useState(() => load('bos_expenses', initialExpenses))
  const [customers, setCustomers] = useState(() => load('bos_customers', [
    { id: 1, name: 'Ada Okafor', phone: '0803 ••• ••21', visits: 8, spent: 74500 },
    { id: 2, name: 'Emeka James', phone: '0806 ••• ••19', visits: 5, spent: 38200 },
    { id: 3, name: 'Grace Ekanem', phone: '0812 ••• ••07', visits: 3, spent: 21900 },
  ]))
  const [page, setPage] = useState('Overview')
  const [search, setSearch] = useState('')
  const [modal, setModal] = useState('')
  const [mobileNav, setMobileNav] = useState(false)
  const [toast, setToast] = useState('')
  const [form, setForm] = useState({})
  const [period, setPeriod] = useState('This week')
  useEffect(() => localStorage.setItem('bos_business', JSON.stringify(business)), [business])
  useEffect(() => localStorage.setItem('bos_products', JSON.stringify(products)), [products])
  useEffect(() => localStorage.setItem('bos_sales', JSON.stringify(sales)), [sales])
  useEffect(() => localStorage.setItem('bos_expenses', JSON.stringify(expenses)), [expenses])
  useEffect(() => localStorage.setItem('bos_customers', JSON.stringify(customers)), [customers])

  const isRetail = /shop|retail|supermarket|pharmacy/i.test(business.type)
  const isService = /salon|service|other/i.test(business.type)
  const currency = n => naira(n)
  const totalSales = sales.reduce((sum, s) => sum + Number(s.amount || 0), 0)
  const totalExpenses = expenses.reduce((sum, e) => sum + Number(e.amount || 0), 0)
  const stockValue = products.reduce((sum, p) => sum + Number(p.cost || 0) * Number(p.stock || 0), 0)
  const lowStock = products.filter(p => p.stock <= 10)
  const nav = [
    { group: 'WORKSPACE', items: [
      { name: 'Overview', icon: LayoutDashboard }, { name: 'Sales & POS', icon: ShoppingCart },
      { name: 'Inventory', icon: Package }, { name: 'Expenses', icon: Wallet },
      { name: 'Customers', icon: Users }, { name: 'Suppliers', icon: Truck },
    ]},
    { group: 'INSIGHTS', items: [
      { name: 'Reports', icon: FileBarChart }, { name: 'AI Business Coach', icon: Sparkles },
    ]},
    { group: 'MANAGE', items: [
      { name: 'Staff & Access', icon: Users }, { name: 'Settings', icon: Settings },
    ]}
  ]
  const notify = msg => { setToast(msg); setTimeout(() => setToast(''), 2800) }
  const openModal = type => { setForm({}); setModal(type) }
  const saveForm = e => {
    e.preventDefault()
    if (modal === 'product') {
      if (!form.name?.trim()) return
      setProducts(prev => [{ id: Date.now(), name: form.name, sku: form.sku || `SKU-${Date.now().toString().slice(-4)}`, category: form.category || 'General', price: Number(form.price || 0), cost: Number(form.cost || 0), stock: Number(form.stock || 0) }, ...prev])
      notify('Product added')
    } else if (modal === 'sale') {
      const product = products.find(p => String(p.id) === String(form.productId))
      if (!product || Number(form.qty || 0) < 1) return
      const qty = Number(form.qty)
      if (product.stock < qty) { notify('Not enough stock for this sale'); return }
      setSales(prev => [{ id: `S-${Date.now().toString().slice(-4)}`, item: `${product.name} × ${qty}`, customer: form.customer || 'Walk-in customer', method: form.method || 'Cash', amount: product.price * qty, date: 'Just now', status: 'Completed' }, ...prev])
      setProducts(prev => prev.map(p => p.id === product.id ? { ...p, stock: p.stock - qty } : p))
      notify('Sale recorded and stock updated')
    } else if (modal === 'expense') {
      if (!form.name?.trim() || Number(form.amount || 0) <= 0) return
      setExpenses(prev => [{ id: `EX-${Date.now().toString().slice(-4)}`, name: form.name, category: form.category || 'General', amount: Number(form.amount), date: 'Today' }, ...prev])
      notify('Expense recorded')
    } else if (modal === 'customer') {
      if (!form.name?.trim()) return
      setCustomers(prev => [{ id: Date.now(), name: form.name, phone: form.phone || 'Not provided', visits: 0, spent: 0 }, ...prev])
      notify('Customer added')
    }
    setModal('')
  }
  const exportCsv = () => {
    const rows = [['Receipt', 'Item', 'Customer', 'Payment method', 'Amount', 'Date'], ...sales.map(s => [s.id, s.item, s.customer, s.method, s.amount, s.date])]
    const csv = rows.map(r => r.map(x => `"${String(x).replaceAll('"', '""')}"`).join(',')).join('\n')
    const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv' })); a.download = 'businessos-sales.csv'; a.click(); URL.revokeObjectURL(a.href)
    notify('Sales CSV exported')
  }
  const resetDemo = () => {
    if (!confirm('Reset all local demo records to the original sample data?')) return
    localStorage.clear(); location.reload()
  }
  const filteredProducts = products.filter(p => `${p.name} ${p.sku} ${p.category}`.toLowerCase().includes(search.toLowerCase()))
  const filteredSales = sales.filter(s => `${s.id} ${s.item} ${s.customer} ${s.method}`.toLowerCase().includes(search.toLowerCase()))
  const filteredCustomers = customers.filter(c => `${c.name} ${c.phone}`.toLowerCase().includes(search.toLowerCase()))
  const heading = {
    'Overview': ['Business overview', 'Here’s what’s happening with your business.'],
    'Sales & POS': ['Sales & POS', 'Record sales and keep every transaction in one place.'],
    'Inventory': ['Inventory management', 'Track products, stock levels and selling prices.'],
    'Expenses': ['Expenses', 'Keep track of the money going out of your business.'],
    'Customers': ['Customers', 'Know your customers and build repeat business.'],
    'Suppliers': ['Suppliers', 'Supplier management is planned for the next release.'],
    'Reports': ['Business reports', 'Review performance and export your sales records.'],
    'AI Business Coach': ['AI Business Coach', 'Practical insights based on the records you enter.'],
    'Staff & Access': ['Staff & Access', 'Role-based access controls are planned for the secure backend release.'],
    'Settings': ['Business settings', 'Customize your workspace to fit your business.']
  }[page] || [page, 'Manage your business.']

  return <div className="app-shell">
    <aside className={`sidebar ${mobileNav ? 'sidebar-open' : ''}`}>
      <div className="brand"><div className="brand-mark"><Activity size={22}/></div><div><b>business<span>OS</span></b><small>NIGERIA</small></div><button className="icon-btn close-nav" onClick={() => setMobileNav(false)}><X size={18}/></button></div>
      <button className="workspace-switch" onClick={() => { setPage('Settings'); setMobileNav(false) }}><div className="workspace-avatar">{(business.name || 'B').slice(0,1).toUpperCase()}</div><div className="workspace-copy"><b>{business.name}</b><small>{business.type}</small></div><ChevronDown size={16}/></button>
      <div className="nav-scroll">{nav.map(section => <div className="nav-section" key={section.group}><div className="nav-label">{section.group}</div>{section.items.map(item => <button key={item.name} className={`nav-item ${page === item.name ? 'active' : ''}`} onClick={() => { setPage(item.name); setSearch(''); setMobileNav(false) }}><item.icon size={18}/><span>{item.name}</span>{item.name === 'Inventory' && lowStock.length > 0 && <i className="nav-count">{lowStock.length}</i>}</button>)}</div>)}</div>
      <div className="sidebar-bottom"><div className="help-card"><div className="help-icon"><CircleHelp size={18}/></div><div><b>Need a hand?</b><p>Learn how to get more from BusinessOS.</p><button onClick={() => notify('Help centre is coming in a future release')}>Visit help centre <span>↗</span></button></div></div><button className="profile-row" onClick={() => { setPage('Settings'); setMobileNav(false) }}><div className="profile-avatar">BO</div><div className="profile-copy"><b>Business Owner</b><small>Owner account · Demo</small></div><MoreHorizontal size={18}/></button></div>
    </aside>
    {mobileNav && <div className="mobile-overlay" onClick={() => setMobileNav(false)} />}
    <main className="main-area">
      <header className="topbar"><div className="top-left"><button className="icon-btn menu-btn" onClick={() => setMobileNav(true)}><Menu size={21}/></button><div className="breadcrumb">Workspace <span>/</span> <b>{page}</b></div></div><div className="top-actions"><label className="searchbox"><Search size={17}/><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search records..." /><kbd>⌘ K</kbd></label><button className="icon-btn notification-btn" onClick={() => notify(lowStock.length ? `${lowStock.length} products need restocking` : 'You’re all caught up')} aria-label="Notifications"><Bell size={19}/>{lowStock.length > 0 && <i/>}</button><div className="top-divider"/><div className="top-user"><div className="profile-avatar">BO</div><div><b>Business Owner</b><small>Administrator</small></div></div></div></header>
      <div className="content">
        <div className="page-heading"><div><div className="eyebrow"><span className="live-dot"/> YOUR BUSINESS, IN CONTROL</div><h1>{heading[0]}</h1><p>{heading[1]}</p></div><div className="heading-actions">{page === 'Overview' && <select className="period-select" value={period} onChange={e => setPeriod(e.target.value)}><option>This week</option><option>This month</option><option>This year</option></select>}{page === 'Inventory' && <button className="primary-btn" onClick={() => openModal('product')}><Plus size={17}/> Add product</button>}{page === 'Sales & POS' && <button className="primary-btn" onClick={() => openModal('sale')}><Plus size={17}/> Record sale</button>}{page === 'Expenses' && <button className="primary-btn" onClick={() => openModal('expense')}><Plus size={17}/> Add expense</button>}{page === 'Customers' && <button className="primary-btn" onClick={() => openModal('customer')}><Plus size={17}/> Add customer</button>}{['Reports','Sales & POS'].includes(page) && <button className="secondary-btn" onClick={exportCsv}><Download size={16}/> Export CSV</button>}</div></div>
        {page === 'Overview' && <Overview business={business} currency={currency} totalSales={totalSales} totalExpenses={totalExpenses} stockValue={stockValue} lowStock={lowStock} sales={sales} products={products} customers={customers} period={period} setPage={setPage} openModal={openModal} exportCsv={exportCsv}/>}
        {page === 'Inventory' && <Inventory products={filteredProducts} currency={currency} openModal={openModal} setProducts={setProducts} notify={notify}/>}
        {page === 'Sales & POS' && <Sales sales={filteredSales} currency={currency} openModal={openModal}/>}
        {page === 'Expenses' && <Expenses expenses={expenses} currency={currency} openModal={openModal}/>}
        {page === 'Customers' && <Customers customers={filteredCustomers} currency={currency} openModal={openModal}/>}
        {page === 'Reports' && <Reports sales={sales} expenses={expenses} currency={currency} totalSales={totalSales} totalExpenses={totalExpenses} exportCsv={exportCsv}/>}
        {page === 'AI Business Coach' && <Coach business={business} lowStock={lowStock} totalSales={totalSales} totalExpenses={totalExpenses} products={products} currency={currency}/>}
        {page === 'Settings' && <SettingsPage business={business} setBusiness={setBusiness} notify={notify} resetDemo={resetDemo}/>}
        {page === 'Suppliers' && <Coming title="Supplier management" body="The next release will include supplier profiles, purchase orders, delivery tracking, and outstanding balances."/>}
        {page === 'Staff & Access' && <Coming title="Staff and permissions" body="The secure backend release will add staff invitations, role-based permissions, activity history, and branch-level access. Do not use this demo for real staff accounts yet."/>}
        <footer className="footer"><span>© 2026 BusinessOS Nigeria</span><span><i className="footer-dot"/> Demo workspace <span className="footer-sep">·</span> Your sample data stays in this browser</span></footer>
      </div>
    </main>
    {modal && <div className="modal-backdrop" onMouseDown={e => { if (e.target === e.currentTarget) setModal('') }}><form className="modal" onSubmit={saveForm}><div className="modal-head"><div><span className="eyebrow">BUSINESSOS WORKSPACE</span><h2>{modal === 'product' ? 'Add a product' : modal === 'sale' ? 'Record a sale' : modal === 'expense' ? 'Add an expense' : 'Add a customer'}</h2></div><button type="button" className="icon-btn" onClick={() => setModal('')}><X size={19}/></button></div>
      {modal === 'product' && <><Field label="Product name" required><input autoFocus value={form.name || ''} onChange={e => setForm({...form, name:e.target.value})} placeholder="e.g. Bottled water" required/></Field><div className="form-grid"><Field label="Selling price (₦)" required><input type="number" min="0" value={form.price || ''} onChange={e => setForm({...form,price:e.target.value})} required/></Field><Field label="Cost price (₦)"><input type="number" min="0" value={form.cost || ''} onChange={e => setForm({...form,cost:e.target.value})}/></Field><Field label="Opening stock" required><input type="number" min="0" value={form.stock ?? ''} onChange={e => setForm({...form,stock:e.target.value})} required/></Field><Field label="Category"><input value={form.category || ''} onChange={e => setForm({...form,category:e.target.value})} placeholder="Food, Drinks..."/></Field></div></>}
      {modal === 'sale' && <><Field label="Product" required><select value={form.productId || ''} onChange={e => setForm({...form,productId:e.target.value})} required><option value="">Choose a product</option>{products.map(p => <option key={p.id} value={p.id}>{p.name} — {currency(p.price)} ({p.stock} in stock)</option>)}</select></Field><div className="form-grid"><Field label="Quantity" required><input type="number" min="1" value={form.qty || '1'} onChange={e => setForm({...form,qty:e.target.value})} required/></Field><Field label="Payment method"><select value={form.method || 'Cash'} onChange={e => setForm({...form,method:e.target.value})}><option>Cash</option><option>Transfer</option><option>POS</option><option>Credit</option></select></Field></div><Field label="Customer name"><input value={form.customer || ''} onChange={e => setForm({...form,customer:e.target.value})} placeholder="Walk-in customer"/></Field></>}
      {modal === 'expense' && <><Field label="Expense description" required><input autoFocus value={form.name || ''} onChange={e => setForm({...form,name:e.target.value})} placeholder="e.g. Electricity bill" required/></Field><div className="form-grid"><Field label="Amount (₦)" required><input type="number" min="1" value={form.amount || ''} onChange={e => setForm({...form,amount:e.target.value})} required/></Field><Field label="Category"><select value={form.category || 'Utilities'} onChange={e => setForm({...form,category:e.target.value})}><option>Utilities</option><option>Inventory</option><option>Staff</option><option>Transport</option><option>Rent</option><option>Marketing</option><option>Other</option></select></Field></div></>}
      {modal === 'customer' && <><Field label="Customer name" required><input autoFocus value={form.name || ''} onChange={e => setForm({...form,name:e.target.value})} required placeholder="Full name"/></Field><Field label="Phone number"><input value={form.phone || ''} onChange={e => setForm({...form,phone:e.target.value})} placeholder="080..."/></Field></>}
      <div className="modal-actions"><button type="button" className="secondary-btn" onClick={() => setModal('')}>Cancel</button><button className="primary-btn" type="submit"><Check size={17}/> Save record</button></div>
    </form></div>}
    {toast && <div className="toast"><Check size={17}/>{toast}</div>}
  </div>
}

function Metric({title,value,change,positive,icon:Icon,iconTone,sub}) {
  return <div className="metric-card"><div className="metric-top"><span>{title}</span><span className={`metric-icon ${iconTone}`}><Icon size={18}/></span></div><div className="metric-value">{value}</div><div className="metric-bottom">{change && <span className={`change ${positive ? 'up':'down'}`}>{positive ? <ArrowUpRight size={14}/>:<ArrowDownRight size={14}/>} {change}</span>}<span>{sub}</span></div></div>
}
function Overview({business,currency,totalSales,totalExpenses,stockValue,lowStock,sales,products,customers,period,setPage,openModal,exportCsv}) {
  const [chartMode,setChartMode] = useState('Sales')
  const data = chartData.map(d => ({...d, expenses: Math.round(d.sales * .52), profit: Math.round(d.sales * .31)}))
  const key = chartMode.toLowerCase()
  const valueForChart = v => currency(v)
  const grossProfit = products.reduce((sum,p) => sum + Math.max(0,p.price-p.cost)*Math.max(0,p.stock),0)
  const tips = [
    lowStock.length ? {tone:'amber',title:`${lowStock.length} items need restocking`,body:`${lowStock.slice(0,2).map(p=>p.name).join(' and ')} ${lowStock.length === 1 ? 'is':'are'} running low. Review stock before your next busy period.`,action:'Review inventory',go:'Inventory'} : {tone:'green',title:'Stock levels look healthy',body:'Keep recording purchases and sales to keep your inventory accurate.',action:'View inventory',go:'Inventory'},
    {tone:'purple',title:'Build your repeat-customer base',body:`You have ${customers.length} customer records. Add customer details at checkout to spot loyal customers.`,action:'View customers',go:'Customers'}
  ]
  return <>
    <div className="welcome-strip"><div className="welcome-icon"><Sparkles size={20}/></div><div><b>Good morning! Your business at a glance.</b><p>Here’s a snapshot of {business.name}. Record every transaction for more useful reports.</p></div><button onClick={() => setPage('AI Business Coach')}>View insights <span>→</span></button></div>
    <div className="section-line"><h2>Performance overview</h2><span><CalendarDays size={15}/> {period}</span></div>
    <div className="metrics-grid">
      <Metric title="Recorded sales" value={currency(totalSales)} change="Demo data" positive icon={Wallet} iconTone="blue" sub="Across saved transactions"/>
      <Metric title="Recorded expenses" value={currency(totalExpenses)} icon={CreditCard} iconTone="orange" sub="Expenses entered so far"/>
      <Metric title="Stock at cost" value={currency(stockValue)} icon={Package} iconTone="purple" sub={`${products.length} products tracked`}/>
      <Metric title="Customer records" value={customers.length.toLocaleString()} icon={Users} iconTone="green" sub="Saved customer profiles"/>
    </div>
    <div className="overview-grid">
      <section className="panel chart-panel"><div className="panel-head"><div><h3>Business activity</h3><p>Illustrative weekly trend · not live bank data</p></div><div className="chart-tabs">{['Sales','Expenses','Profit'].map(m=><button className={chartMode===m?'selected':''} key={m} onClick={()=>setChartMode(m)}>{m}</button>)}</div></div><div className="chart-summary"><b>{currency(data.reduce((s,d)=>s+d[key],0))}</b><span className="chart-summary-label">Illustrative {chartMode.toLowerCase()}</span></div><div className="chart-wrap"><ResponsiveContainer width="100%" height="100%"><AreaChart data={data} margin={{top:10,right:4,left:0,bottom:0}}><defs><linearGradient id="salesFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#4f7cff" stopOpacity={0.22}/><stop offset="95%" stopColor="#4f7cff" stopOpacity={0}/></linearGradient></defs><CartesianGrid stroke="#edf0f5" vertical={false}/><XAxis dataKey="day" axisLine={false} tickLine={false} tick={{fill:'#8b95a7',fontSize:12}} dy={12}/><Tooltip formatter={v=>currency(v)} contentStyle={{border:'1px solid #e8ecf3',borderRadius:12,fontSize:12}}/><Area type="monotone" dataKey={key} stroke="#4f7cff" strokeWidth={2.5} fill="url(#salesFill)" activeDot={{r:5,strokeWidth:0}}/></AreaChart></ResponsiveContainer></div><div className="chart-foot"><span><i className="legend-dot"/> {chartMode} activity</span><span>Sample trend for UI preview</span></div></section>
      <section className="panel"><div className="panel-head"><div><h3>Needs your attention</h3><p>Useful next steps for your business</p></div><span className="soft-count">{tips.length}</span></div><div className="attention-list">{tips.map((t,i)=><div className="attention-item" key={t.title}><div className={`attention-icon ${t.tone}`}>{i===0?<Package size={18}/>:<Users size={18}/>}</div><div className="attention-copy"><b>{t.title}</b><p>{t.body}</p><button onClick={()=>setPage(t.go)}>{t.action} <span>→</span></button></div></div>)}</div><div className="mini-tip"><Sparkles size={16}/><span><b>Tip:</b> Record sales consistently to make your reports more useful.</span></div></section>
    </div>
    <section className="panel table-panel"><div className="panel-head"><div><h3>Recent transactions</h3><p>Your latest saved sales records</p></div><button className="text-btn" onClick={()=>setPage('Sales & POS')}>View all transactions <span>→</span></button></div><TransactionTable sales={sales.slice(0,5)} currency={currency}/></section>
    <div className="quick-actions"><button onClick={()=>openModal('sale')}><span className="quick-icon blue"><ShoppingCart size={18}/></span><span><b>Record a sale</b><small>Add a new transaction</small></span><Plus size={17}/></button><button onClick={()=>openModal('product')}><span className="quick-icon purple"><Package size={18}/></span><span><b>Add inventory</b><small>Create a product record</small></span><Plus size={17}/></button><button onClick={()=>openModal('expense')}><span className="quick-icon orange"><ReceiptText size={18}/></span><span><b>Log an expense</b><small>Track money going out</small></span><Plus size={17}/></button></div>
  </>
}
function TransactionTable({sales,currency}) {
  return <div className="table-scroll"><table><thead><tr><th>TRANSACTION</th><th>CUSTOMER</th><th>PAYMENT</th><th>DATE</th><th className="align-right">AMOUNT</th><th>STATUS</th></tr></thead><tbody>{sales.map(s=><tr key={s.id}><td><div className="transaction-cell"><span className="transaction-icon"><ReceiptText size={16}/></span><span><b>{s.item}</b><small>{s.id}</small></span></div></td><td>{s.customer}</td><td><span className="payment-pill">{s.method}</span></td><td className="muted-cell">{s.date}</td><td className="align-right amount-cell">{currency(s.amount)}</td><td><span className="status-pill"><i/>{s.status}</span></td></tr>)}</tbody></table>{sales.length===0&&<div className="empty-state">No records found. Try another search or add a record.</div>}</div>
}
function Inventory({products,currency,openModal,setProducts,notify}) {
  return <><div className="metrics-grid compact-metrics"><Metric title="Products listed" value={products.length} icon={Package} iconTone="blue" sub="Filtered product records"/><Metric title="Low stock" value={products.filter(p=>p.stock<=10).length} icon={Activity} iconTone="orange" sub="10 units or fewer"/><Metric title="Inventory cost value" value={currency(products.reduce((s,p)=>s+p.cost*p.stock,0))} icon={Wallet} iconTone="purple" sub="Based on entered cost price"/></div><section className="panel table-panel"><div className="panel-head"><div><h3>Products and stock</h3><p>Manage the products you sell</p></div><button className="primary-btn" onClick={()=>openModal('product')}><Plus size={16}/> Add product</button></div><div className="table-scroll"><table><thead><tr><th>PRODUCT</th><th>CATEGORY</th><th>SELLING PRICE</th><th>COST PRICE</th><th>STOCK</th><th>STATUS</th><th></th></tr></thead><tbody>{products.map(p=><tr key={p.id}><td><div className="transaction-cell"><span className="product-avatar"><Package size={17}/></span><span><b>{p.name}</b><small>{p.sku}</small></span></div></td><td>{p.category}</td><td className="amount-cell">{currency(p.price)}</td><td>{currency(p.cost)}</td><td>{p.stock}</td><td><span className={`stock-pill ${p.stock<=5?'critical':p.stock<=10?'low':'healthy'}`}>{p.stock<=5?'Very low':p.stock<=10?'Low stock':'In stock'}</span></td><td><button className="icon-btn" title="Delete product" onClick={()=>{if(confirm(`Delete ${p.name}?`)){setProducts(prev=>prev.filter(x=>x.id!==p.id));notify('Product deleted')}}}><MoreHorizontal size={18}/></button></td></tr>)}</tbody></table>{products.length===0&&<div className="empty-state">No products found. Add your first product.</div>}</div></section></>
}
function Sales({sales,currency,openModal}) { return <section className="panel table-panel"><div className="panel-head"><div><h3>Sales history</h3><p>Each record is stored locally in this demo browser.</p></div><button className="primary-btn" onClick={()=>openModal('sale')}><Plus size={16}/> Record sale</button></div><TransactionTable sales={sales} currency={currency}/></section> }
function Expenses({expenses,currency,openModal}) { return <section className="panel table-panel"><div className="panel-head"><div><h3>Expense records</h3><p>Track operating costs and everyday spending.</p></div><button className="primary-btn" onClick={()=>openModal('expense')}><Plus size={16}/> Add expense</button></div><div className="table-scroll"><table><thead><tr><th>DESCRIPTION</th><th>CATEGORY</th><th>DATE</th><th className="align-right">AMOUNT</th></tr></thead><tbody>{expenses.map(e=><tr key={e.id}><td><div className="transaction-cell"><span className="transaction-icon expense"><ReceiptText size={16}/></span><span><b>{e.name}</b><small>{e.id}</small></span></div></td><td><span className="payment-pill">{e.category}</span></td><td className="muted-cell">{e.date}</td><td className="align-right amount-cell">{currency(e.amount)}</td></tr>)}</tbody></table>{!expenses.length&&<div className="empty-state">No expenses yet. Add your first expense.</div>}</div></section> }
function Customers({customers,currency,openModal}) { return <section className="panel table-panel"><div className="panel-head"><div><h3>Customer directory</h3><p>Keep customer information organized.</p></div><button className="primary-btn" onClick={()=>openModal('customer')}><Plus size={16}/> Add customer</button></div><div className="table-scroll"><table><thead><tr><th>CUSTOMER</th><th>PHONE</th><th>VISITS</th><th className="align-right">TOTAL SPENT</th></tr></thead><tbody>{customers.map(c=><tr key={c.id}><td><div className="transaction-cell"><span className="customer-avatar">{c.name.split(' ').map(x=>x[0]).join('').slice(0,2)}</span><b>{c.name}</b></div></td><td>{c.phone}</td><td>{c.visits}</td><td className="align-right amount-cell">{currency(c.spent)}</td></tr>)}</tbody></table>{!customers.length&&<div className="empty-state">No customers found. Add a customer record.</div>}</div></section> }
function Reports({sales,expenses,currency,totalSales,totalExpenses,exportCsv}) {
  const net = totalSales-totalExpenses
  return <><div className="metrics-grid"><Metric title="Recorded sales" value={currency(totalSales)} icon={TrendingUp} iconTone="blue" sub="All sales currently saved"/><Metric title="Recorded expenses" value={currency(totalExpenses)} icon={Wallet} iconTone="orange" sub="All expenses currently saved"/><Metric title="Simple difference" value={currency(net)} icon={FileBarChart} iconTone={net>=0?'green':'orange'} sub="Sales minus entered expenses"/><Metric title="Transactions" value={sales.length} icon={ReceiptText} iconTone="purple" sub="Saved sales records"/></div><section className="panel report-note"><div className="attention-icon purple"><FileBarChart size={20}/></div><div><h3>Sales export</h3><p>Download your saved sales records as a CSV file you can open in Excel or Google Sheets.</p><button className="primary-btn" onClick={exportCsv}><Download size={16}/> Export sales CSV</button></div></section><p className="disclaimer">Important: the simple difference above is not audited profit. It excludes cost of goods sold, taxes, refunds, unpaid credit, and other unrecorded transactions. Sample records are included for demonstration.</p></>
}
function Coach({business,lowStock,totalSales,totalExpenses,products,currency}) {
  const gross = products.reduce((s,p)=>s+(p.price-p.cost)*p.stock,0)
  return <><div className="coach-hero"><div className="coach-orb"><Sparkles size={28}/></div><div><div className="eyebrow">BUSINESS INTELLIGENCE PREVIEW</div><h2>Your business snapshot</h2><p>Early insights from the records in this demo workspace.</p></div></div><div className="insight-grid"><div className="insight-card"><span className="attention-icon amber"><Package size={18}/></span><div><b>Stock attention</b><p>{lowStock.length ? `${lowStock.length} item(s) are low on stock. Check recent demand before buying more.`:'No low-stock items in the current inventory.'}</p></div></div><div className="insight-card"><span className="attention-icon green"><Wallet size={18}/></span><div><b>Money recorded</b><p>Saved sales total {currency(totalSales)} and saved expenses total {currency(totalExpenses)}. These totals only include the demo records you entered.</p></div></div><div className="insight-card"><span className="attention-icon purple"><BriefcaseBusiness size={18}/></span><div><b>Next step for {business.type.toLowerCase()}</b><p>{/restaurant|bar/i.test(business.type)?'Track ingredient purchases and portion costs to estimate the profitability of each menu item.':/shop|retail|supermarket|pharmacy/i.test(business.type)?'Record supplier purchases and sales consistently to improve stock and margin visibility.':'Record all income and operating costs to understand your business performance.'}</p></div></div></div><div className="notice-box"><Sparkles size={17}/><span><b>AI is not connected yet.</b> These are rule-based tips, not generated AI advice. A future release can connect a model through a secure backend without exposing your API key in the browser.</span></div></>
}
function SettingsPage({business,setBusiness,notify,resetDemo}) {
  const update = (key,value)=>setBusiness(prev=>({...prev,[key]:value}))
  return <div className="settings-layout"><section className="panel settings-panel"><div className="panel-head"><div><h3>Business profile</h3><p>Set up BusinessOS around your business.</p></div><Building2 size={20} className="settings-symbol"/></div><div className="settings-form"><Field label="Business name"><input value={business.name} onChange={e=>update('name',e.target.value)} /></Field><Field label="Business type"><select value={business.type} onChange={e=>update('type',e.target.value)}><option>Restaurant / Bar</option><option>Provision shop / Retail</option><option>Supermarket</option><option>Pharmacy</option><option>Salon / Personal services</option><option>Other business</option></select></Field><Field label="Number of staff"><select value={business.staff} onChange={e=>update('staff',e.target.value)}><option>Just me</option><option>2–5 staff</option><option>6–15 staff</option><option>16+ staff</option></select></Field><Field label="Business locations"><select value={business.branches} onChange={e=>update('branches',e.target.value)}><option>1 location</option><option>2–5 locations</option><option>6+ locations</option></select></Field><Field label="Main business goal"><select value={business.goal} onChange={e=>update('goal',e.target.value)}><option>Know my real profit</option><option>Track sales and expenses</option><option>Manage stock</option><option>Manage staff</option><option>Grow repeat customers</option></select></Field><div className="settings-save"><span><Check size={15}/> Changes save automatically in this browser</span><button className="secondary-btn" onClick={()=>notify('Business profile updated')}>Confirm settings</button></div></div></section><section className="panel settings-panel"><div className="panel-head"><div><h3>Workspace and data</h3><p>Demo mode information</p></div><Settings size={20} className="settings-symbol"/></div><div className="setting-info"><div><b>Local demo storage</b><p>Records are stored in this browser using localStorage. They are not synced to another device or backed up to a server.</p></div><span className="stock-pill low">Demo</span></div><div className="setting-info"><div><b>Security and accounts</b><p>Real login, password reset, team permissions, and tenant isolation must be added before production use.</p></div><span className="stock-pill low">Not live</span></div><div className="danger-zone"><b>Reset demo data</b><p>Remove local sample records and restore the original demo workspace.</p><button className="danger-btn" onClick={resetDemo}>Reset sample data</button></div></section></div>
}
function Coming({title,body}) { return <section className="panel coming-panel"><div className="coming-icon"><Sparkles size={24}/></div><h2>{title}</h2><p>{body}</p><span className="stock-pill low">Planned feature</span></section> }
function Field({label,required,children}) { return <label className="field"><span>{label}{required&&<i> *</i>}</span>{children}</label> }

createRoot(document.getElementById('root')).render(<App />)
